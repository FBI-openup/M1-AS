/* bit manipulation */


int func1(int);
int test_func1(int);


int func2(int, int);
int test_func2(int, int);


int func3(int);
int test_func3(int);


int func4(int);
int test_func4(int);


int func5();
int test_func5();


int func6(int, int);
int test_func6(int, int);


int func7(int);
int test_func7(int);


/* 2's complement */


int func8();
int test_func8();


int func9(int);
int test_func9(int);


int func10(int);
int test_func10(int);


int func11(int, int);
int test_func11(int, int);


int func12(int);
int test_func12(int);


int func13(int, int);
int test_func13(int, int);


